/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.project.spring;

/**
 *
 * @author mrahman1s
 */
public class Grade {
    private String subject;
    private char letterGrade;

    public Grade() {
    }
    
    

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public char getLetterGrade() {
        return letterGrade;
    }

    public void setLetterGrade(char letterGrade) {
        this.letterGrade = letterGrade;
    }

    public Grade(String subject, char letterGrade) {
        this.subject = subject;
        this.letterGrade = letterGrade;
    }
    @Override
    public String toString() {
        return "Grade{" + "subject=" + subject + ", letterGrade=" + letterGrade + '}';
    }
   
}
