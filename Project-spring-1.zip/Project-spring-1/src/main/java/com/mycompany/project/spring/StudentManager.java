/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.project.spring;


import java.util.ArrayList;
import java.util.List;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 *
 * @author mrahman1s
 */
public class StudentManager {

    public static void displayAll() {
        List<Student> student = new ArrayList<>();
        // The argument is an int array.
        for (Student value : student) {
            System.out.println(value);
        }
        // System.out.println("DONE");
    }

    public static void main(String[] args) {

       // Student student = new Student(); 
        displayAll();
        ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("Project_Spring.xml");
   Student student =(Student) context.getBean("student");
  // student.toString();
   
//    
        System.out.println(student.toString());
        Address address = (Address) context.getBean("address");
        System.out.println(address.toString());
        Grade grade =(Grade) context.getBean("grade");
        System.out.println(grade.toString());
    }
}
